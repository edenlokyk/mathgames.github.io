# PSLE Math Speed Challenge 🎯

A browser-based speed quiz game built for **Sonia**, a Primary 6 student preparing for the Singapore PSLE Mathematics examination.

All questions are aligned to the **MOE 2021 Primary 6 Standard Mathematics Syllabus** (updated October 2025).

---

## Play it

No build step. No dependencies. Just open the file:

```
open index.html
```

Or deploy the single file to any static host (GitHub Pages, Netlify, etc.).

> **Note — fonts:** The game loads *Fredoka One* and *Nunito* from Google Fonts at runtime. It works offline but will fall back to system fonts without an internet connection.

---

## How to play

1. **Pick a topic** — Mixed, Algebra, Fractions & %, Ratio, Speed, or Geometry
2. **Pick a difficulty** — Easy (20 s), Medium (15 s), or Hard (10 s)
3. Answer **10 questions** before the timer runs out
4. Earn **speed bonus points** for fast correct answers
5. Build **combo streaks** for milestone animations (3×, 5×, 7×)
6. Review every question with hints at the end

---

## Syllabus coverage

| Topic | MOE Syllabus Reference |
|---|---|
| **Algebra** | P6 Number & Algebra — using letters, simplifying expressions, simple linear equations |
| **Fractions & Percentage** | P6 Fractions (four operations), P5–6 Percentage (discount, GST, % change) |
| **Ratio** | P6 Ratio — equivalent ratios, dividing quantities, relationship with fractions |
| **Speed** | P6 Rate — distance/time/speed, average speed, multi-step word problems |
| **Geometry** | P6 Measurement & Geometry — angles, area/perimeter, circles, volume |

---

## Project structure

```
psle-math-game/
├── index.html   # Complete game — HTML + CSS + JS in one file
├── README.md    # This file
└── LICENSE      # MIT licence
```

The entire game is a **single self-contained HTML file** so it can be opened directly from any folder or shared as an attachment without needing a server.

---

## Technical notes

- **No frameworks or build tools** — vanilla HTML/CSS/JS, `'use strict'`
- **Single source of truth for timer** — difficulty limits live in one `MAX_TIME` constant, referenced everywhere
- **Fisher-Yates shuffle** — questions are randomised using a statistically uniform algorithm
- **DOM-safe review panel** — end-of-game review built with `textContent` and DOM methods, not `innerHTML` string interpolation
- **SVG attributes** — timer ring `r`, `cx`, `cy` are set as HTML presentation attributes on the `<circle>` elements, not as CSS properties
- **All game state in one object** — `const Game = { ... }` — no loose global variables

---

## Adding or editing questions

Questions live in the `QUESTIONS` object inside `index.html`. Each entry follows this schema:

```js
{
  d:     'easy' | 'medium' | 'hard',  // difficulty tier
  q:     'Question text',             // shown to the player
  opts:  ['A', 'B', 'C', 'D'],        // exactly 4 answer choices
  ans:   0,                           // 0-based index of the correct choice
  topic: 'Display Label',             // shown in the game HUD
  hint:  'Shown after a wrong answer or timeout',
}
```

---

## Licence

MIT — see [LICENSE](LICENSE).
